package et.dev.eyobed.vqueue.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import et.dev.eyobed.vqueue.R;
import et.dev.eyobed.vqueue.utils.PermissionGranter;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.preference.PreferenceManager;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private NavController navController;
    private AppBarConfiguration appBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);        

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String theme = prefs.getString("theme_preference", "system");

        // Apply the theme fast
        switch (theme) {
            case "light":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case "dark":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case "system":
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
        }
        setContentView(R.layout.activity_main);

        // window insets for edge to edge stuff
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_root), (v, insets) -> {
            // Extract system bar insets 
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());

            // Apply bottom padding to the root view to accommodate the navigation bar
            v.setPadding(v.getPaddingLeft(), v.getPaddingTop(), v.getPaddingRight(), systemBars.bottom);

            // Apply top padding for the status bar
            View toolbar = findViewById(R.id.mainToolbar);
            if (toolbar != null) {
                toolbar.setPadding(toolbar.getPaddingLeft(), systemBars.top, toolbar.getPaddingRight(),
                        toolbar.getPaddingBottom());
            }

            return insets;
        });

        setupPermissions();
        setupNavigation();
    }

    //deals with permissions
    private void setupPermissions() {
        ActivityResultLauncher<String[]> permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    if (result.isEmpty()) {
                        return; // Already granted, callback shouldn't have fired so ignore
                    }
                    boolean anyDenied = false;
                    for (Boolean granted : result.values()) {
                        if (granted == null || !granted) {
                            anyDenied = true;
                            break;
                        }
                    }
                    if (anyDenied) {
                        showPermissionDeniedDialog();
                    }

                });

        PermissionGranter permissionHandler = new PermissionGranter(this, permissionLauncher);
        permissionHandler.requestAllIfNeeded();
    }

    //deals with navigation
    private void setupNavigation() {
        // Find and setup the global toolbar
        Toolbar mainToolbar = findViewById(R.id.mainToolbar);
        setSupportActionBar(mainToolbar);

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.fragmentContainer);

        if (navHostFragment == null) {
            throw new IllegalStateException(
                    "NavHostFragment not found.");
        }

        navController = navHostFragment.getNavController();

        appBarConfiguration = new AppBarConfiguration.Builder(R.id.homeFragment).build();

        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

    }

    //deals with permission denied dialog
    private void showPermissionDeniedDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Permissions Required")
                .setMessage(
                        "This app requires certain permissions to function properly. You need to grant them in settings")
                .setPositiveButton("OK", null)
                .show();
    }
    
    @Override
    public boolean onSupportNavigateUp() {
        if (navController == null) {
            return super.onSupportNavigateUp();
        }
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }


}